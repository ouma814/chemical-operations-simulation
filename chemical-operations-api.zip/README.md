# TP Modélisation — Chemical Operations

API FastAPI qui calcule les étapes de filtration, mélange, chauffage, évaporation et refroidissement.

## Lancer dans VS Code

1. Ouvre le terminal intégré (**Terminal → Nouveau terminal**).
2. Installe les dépendances :

   ```powershell
   py -m pip install -r requirements.txt
   ```

3. Démarre l'API :

   ```powershell
   py main.py
   ```

4. Ouvre la documentation interactive : <http://127.0.0.1:8000/docs>
5. Dans `POST /run-tp`, clique **Try it out**, puis **Execute** pour lancer une simulation.

La page d'accueil est disponible sur <http://127.0.0.1:8000/>. Le serveur reste accessible uniquement depuis ton ordinateur. Pour obtenir un lien public, il faudra déployer l'application sur un hébergeur.

## Hypothèse de calcul

La filtration suppose que toute la matière soluble passe dans le filtrat; les résidus représentent uniquement la masse retirée.
